

 `pip install -r requirements.txt`
 `python manage.py makemigrations`
 `python manage.py migrate`
 Запустить сервер - `python manage.py runserver`


